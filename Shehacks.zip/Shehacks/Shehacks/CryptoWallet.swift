//
//  CryptoWallet.swift
//  Shehacks
//
//  Created by Rodaba Ebadi on 2022-01-08.
//

import SwiftUI

struct CryptoWallet: View {
    var body: some View {
       Text("")
    }
}

struct CryptoWallet_Previews: PreviewProvider {
    static var previews: some View {
        CryptoWallet()
    }
}
