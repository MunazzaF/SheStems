//
//  ShehacksApp.swift
//  Shehacks
//
//  Created by Rodaba Ebadi on 2022-01-08.
//

import SwiftUI

@main
struct ShehacksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
